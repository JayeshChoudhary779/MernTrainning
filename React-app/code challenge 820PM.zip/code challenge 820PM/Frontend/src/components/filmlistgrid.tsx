
import './filmlistgrid.css';
import { useHistory,Link} from 'react-router-dom';
import {useState,useEffect} from "react";

 function Filmlistgrid(){
   
const history = useHistory();
  const[myFilms,setFilms]= useState([]);

  useEffect(()=>{
  getlist();
  },[]);

  // function selectFilm(film:any){
  // }
 
  
  function getlist(){
    fetch('http://localhost:4555/app/film/getFilm',{
      method:"GET",
      headers:{"Content-Type":"application/json"}
    })
    .then(res=>{
      return res.json();
    })
    .then(data=>{
      setFilms(data);  
    });
  }

  function deleteFilmgrid(name:any){
    console.log(name)
    fetch(`http://localhost:4555/app/film/deleteFilm/${name}`,{
      method:'DELETE'
    }).then((result)=>{
      getlist();
      result.json().then((resp)=>(
        console.log(resp)
      ))
      })
  }

    return(
      
          <div className="bgimageh">
          
          <br/>
          <br/>
          <div style={{display:"block", clear:"left" ,color:"black"}}>
          <h2>Film List :</h2>
          </div>
          
          
          <div className="grid-container">
        {
          myFilms.map((post:any)=>{ 
              return(
                 
                    <div className="grid-item">
                    <b>Film name : </b> 
                    {post.name}
                    {/* <Link to="/filmDetails" onClick={()=>{selectFilm(post)}}>{post.name}</Link>  */}

                    <br/><b>Director name : </b> 
                     {post.dname}
                    <br/><b>Box-Office Collection : </b> 
                     {post.boxOfficeCollection}
                    <br/><b>Rating : </b>
                     {post.rating}
                     <br/><button onClick={()=>{deleteFilmgrid(post.name)}} id="searchBut">Delete</button>              
                    </div>    
              );
              
        }
       
        ) }
        </div>
        </div>
      
    );
}

export default Filmlistgrid;
