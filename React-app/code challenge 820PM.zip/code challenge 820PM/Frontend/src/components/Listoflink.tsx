
import {Link} from 'react-router-dom';

function List(){
    return(
<div className="topnav2">
<ul>
    
<Link to={`/`}><li><a href="#add Author">Home</a></li></Link>
<Link to={`/Filmsgrid`}><li><a href="#Books">Films</a></li></Link>
<Link to={`/Add_Films`}><li><a href="#Add Book">Add Film</a></li></Link>
<Link to={`/Add_Directors`}><li><a href="#Author">Add Director</a></li></Link>
<Link to={`/Directorsgrid`}><li><a href="#Author">Directors</a></li></Link>
</ul>
</div>
    )}

export default List;