
import './filmlistgrid.css';
import {BrowserRouter as Router, useHistory, Switch, Route,Link} from 'react-router-dom';
import {useState,useEffect} from "react";

 function Directorlistgrid(){
   
const history = useHistory();
  const[myDirectors,setDirectors]= useState([]);

  useEffect(()=>{
  getlist();
  },[]);

  // function selectDirector(director:any){
  //   history.push("/directorDetails")
  // }
 
  
  function getlist(){
    fetch('http://localhost:4555/app/director/getDirector',{
      method:"GET",
      headers:{"Content-Type":"application/json"}
    })
    .then(res=>{
      return res.json();
    })
    .then(data=>{
      setDirectors(data);  
    });
  }

  function deleteDirectorgrid(name:any){
    console.log(name)
    fetch(`http://localhost:4555/app/director/deleteDirector/${name}`,{
      method:'DELETE'
    }).then((result)=>{
      getlist();
      result.json().then((resp)=>(
        console.log(resp)
      ))
      })
  }

  
    return(
      
          <div className="bgimageh">
          
          <br/>
          <br/>
          <div style={{display:"block", clear:"left" ,color:"black"}}>
          <h2>Director List :</h2>
          </div>
          
          
          <div className="grid-container">
        {
          myDirectors.map((post:any)=>{ 
              return(
                 
                    <div className="grid-item">
                    <b>Director Name : </b> 
                    {post.dname}
                    {/* <Link to="/directorDetails" onClick={()=>{selectDirector(post)}}>{post.dname}</Link> */}

                    <br/><b>Director Age: </b> 
                     {post.age}
                    <br/><b>Gender : </b> 
                     {post.gender}
                    <br/><b>Award Count : </b>
                     {post.awardCount}
                     <br/><button onClick={()=>{deleteDirectorgrid(post.dname)}} id="searchBut">Delete</button>              
                    </div>    
              );
              
        }
       
        ) }
        </div>
        </div>
      
    );
}

export default Directorlistgrid;
