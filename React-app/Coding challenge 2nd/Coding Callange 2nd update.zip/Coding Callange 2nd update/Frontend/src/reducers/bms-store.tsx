
export interface Store{
 screen:any;
 show:any;
}

export const store:Store={
    screen:localStorage.getItem('screen'),
    show:''
}