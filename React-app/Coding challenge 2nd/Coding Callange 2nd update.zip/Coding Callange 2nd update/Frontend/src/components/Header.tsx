
import './header.css';
import {Link} from 'react-router-dom';
import {useContext} from 'react';
import {bmsContext} from "../reducers/bms-context";

function Header(){ 
    
let {screen}=useContext(bmsContext);
const token= localStorage.getItem("authToken")
console.log("screen :" +screen)
console.log("token :" +token)

       return (
<div className="navigation">
<div className="topnav1">
<h1 style ={{color: "white", marginLeft:".5rem"}}>E-Shop </h1>
</div>

<div className="topnav2">
<ul>
    
{
(screen==="user")?<>
<Link to={`/`}><li style={{marginLeft:"1rem"}} key="uniqueId1">User Home</li></Link>
<Link to={`/Goodsgrid`}><li key="uniqueId2">Items/Shops</li></Link></>
:null
}
{
(screen==="customer")?<>
<Link  to={`/`}><li style={{marginLeft:"1rem"}} key="uniqueId1">Customer/Shop Home</li></Link>
<Link to={`/Shopsgrid`}><li key="uniqueId3">View Shops</li></Link>
<Link to={`/Add_Shops`}><li key="uniqueId4">Add Shop</li></Link></>
:null
}
{
(screen==="admin")?<>
<Link to={`/`}><li style={{marginLeft:"1rem"}} key="uniqueId1">Admin Home</li></Link>
<Link to={`/View_Category`}><li key="uniqueId5">Add/View Category</li></Link></>
:null
}
{
(token!==null)?<>
<Link to={`/logout`}><li key="uniqueId6" style={{float:"right"}}>LogOut</li></Link></>
:<>
<Link to={`/register`}><li key="uniqueId7" style={{float:"right"}}>Register</li></Link>
<Link to={`/login`}><li key="uniqueId8" style={{float:"right"}}>Login</li></Link></>
}


</ul>
</div>

</div>
    );
}

export default Header;