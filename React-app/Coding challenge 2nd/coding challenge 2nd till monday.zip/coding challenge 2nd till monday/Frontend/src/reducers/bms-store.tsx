
export interface Store{
 screen:any;
}

export const store:Store={
    screen:localStorage.getItem('screen')
}