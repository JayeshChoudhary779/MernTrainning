
import { useHistory } from 'react-router-dom';
import './Addshopstyle.css';
import  { useState } from 'react';
import Axios from "axios";

function Addshop(){
    
  
const token= localStorage.getItem("authToken")
const[message,setMessage]=useState("");
const history = useHistory();

    
    const[sname,setName]=useState("");
    const[owner,setOwner]=useState("");
    const[offer,setOffer]=useState("");
    const[location,setLocation]=useState("");
    const[category,setCategory]=useState("");
    const[product,setProducts]=useState("");
  
    let products=product.split(",")
    function submit(e:any){
     e.preventDefault();
     if ( sname ==="" || owner==="" || location === ""||category === ""||product===""||offer==="'") {
        alert("All the fields are mandatory!");
        return;
      }
    console.log('hyy')
    let data={sname,owner,location,category,offer,products};

    console.log(data);
     

    Axios.post("http://localhost:4555/app/shop/add",data)
    .then(res=>{
      const{...data1}= res.data;
     if(data1.message!==""){
       setMessage(data1.message)
       console.log(data1.message)
     }
     if(data1.message==="unique name"){
    history.push("/Shopsgrid");
     }
    })
    .catch(error=>{
        console.log(error)
    });
    
    }
    if(token==null){
      return <> <h1>Please First Login, Thank You!</h1> </>;;
     }else{
return(
  
<div className="bgimage">
    <div className="container">
       
  <h2 style ={{}}>Add new Shop details...</h2>
  <hr style={{color:"black", borderWidth:2}} />
                   
         <form onSubmit={submit}>
             
                     <b><label>Shop name :</label></b>
                     <input type="text" id="name" placeholder="Shop name.." name="sname" value={sname} onChange={(e)=>setName(e.target.value)}/>
                     <br/>
                     <b><label>Owner name :</label></b>
                     <input type="text" id="owner" placeholder="owner..." name="owner" value={owner} onChange={(e)=>setOwner(e.target.value)}/>
                     <br/>
                     <b><label>Location :</label></b>
                     <input type="text" id="location" placeholder="location..." name="location" value={location} onChange={(e)=>setLocation(e.target.value)}/>
                     <br/>
                     <b><label>Category :</label></b>
                     <input type="text" id="category" placeholder="category..."name="category" value={category} onChange={(e)=>setCategory(e.target.value)} />
                     <b><label>Offer :</label></b>
                     <input type="text" id="offer" placeholder="offer..."name="offer" value={offer} onChange={(e)=>setOffer(e.target.value)} />
                     <b><label>Products by comma :</label></b>
                     <input type="text" id="products" placeholder="product1,product2,product3......"name="products" value={product} onChange={(e)=>setProducts(e.target.value)} />
    
                     <b style={{color:"red"}}>{
  (message!="")?
  message:null
}</b>
<br/>
<br/>
                     <input type ="submit" value='ADD SHOP' id="addbutton" />

                   </form>
                 </div>
                 </div>
               
       );
    
}}
export default Addshop;

