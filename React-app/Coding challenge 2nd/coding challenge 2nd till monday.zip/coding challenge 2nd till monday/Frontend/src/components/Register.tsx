
import './register.css';
import {Link} from 'react-router-dom';
import Axios from "axios";
import {useState,useContext} from 'react';
function Register(){

  const[message,setMessage]=useState("");
  
const[show,setShow]=useState("option");
  const[phoneNo,setPhoneNo]=useState("");
  const[uname,setUname]=useState("");
  const[aname,setAname]=useState("");
  const[cname,setCname]=useState("");
  
  const[email,setEmail]=useState("");
  const[password,setPassword]=useState("");
  const[passwordc,setPasswordc]=useState("");


  function submitUser(e:any){
    e.preventDefault();
    
    if (password !== passwordc) {
       alert("Enter same password in both the field");
       return;
     }
   console.log('hyy')
   let data={uname,email,password,phoneNo};

   console.log(data);

   
  
   Axios.post("http://localhost:4555/app/user/signUp",data)
   .then(res=>{
     const{...data}= res.data;
    if(data.message!==""){
      setMessage(email + " "+data.message)
    }
   })
   .catch(error=>{
       console.log(error)
   });
  }

  function submitCustomer(e:any){
    e.preventDefault();
    
    if (password !== passwordc) {
       alert("Enter same password in both the field");
       return;
     }
   console.log('hyy')
   let data={cname,email,password,phoneNo};

   console.log(data);

   
  
   Axios.post("http://localhost:4555/app/customer/signUp",data)
   .then(res=>{
     const{...data}= res.data;
    if(data.message!==""){
      setMessage(email + " "+data.message)
    }
   })
   .catch(error=>{
       console.log(error)
   });
  }

  function submitAdmin(e:any){
    e.preventDefault();
    
    if (password !== passwordc) {
       alert("Enter same password in both the field");
       return;
     }
   console.log('hyy')
   let data={aname,email,password,phoneNo};

   console.log(data);

   
  
   Axios.post("http://localhost:4555/app/admin/signUp",data)
   .then(res=>{
     const{...data}= res.data;
    if(data.message!==""){
      setMessage(email + " "+data.message)
    }
   })
   .catch(error=>{
       console.log(error)
   });
  }

    return(

      <>
      {
     (show==="option")?
     <div>      
         <button className="buttonlo" type="submit" onClick={()=>{setShow("user")}}>User Register</button>
         <h4 style={{margin:"0 auto",textAlign:"center" }}>OR</h4>
         <button className="buttonlo" type="submit" onClick={()=>{setShow("customer")}}>Customer/Shop Register</button>
         <h4 style={{margin:"0 auto", textAlign:"center"}}>OR</h4>
         <button className="buttonlo" type="submit" onClick={()=>{setShow("admin")}}>Admin Register</button>
         </div>
         :    
         (show==="user")?
<>
          <Link to="/register" style={{marginLeft:"1rem", fontSize:"1.3rem" ,color:"#102030"}} onClick={()=>{setShow("option")}}>Go Back</Link>
    <form onSubmit={submitUser}>
    <div className="containerrrr">
    <h1>User Register</h1>
    <p>Please fill in this form to create an account.</p>
    <hr/>
  

    <label><b>User name</b></label>
    <input type="text" placeholder="Enter username" name="uname" id="uname" required   value={uname}  onChange={(e)=>setUname(e.target.value)}/>

    <label><b>Email</b></label>
    <input type="text" placeholder="Enter Email" name="email" id="email" required  value={email}  onChange={(e)=>setEmail(e.target.value)}/>
    
    <label><b>Phone No.</b></label>
    <input type="text" placeholder="Enter phoneNo" name="phoneNo" id="phoneNo" required  value={phoneNo}  onChange={(e)=>setPhoneNo(e.target.value)}/>

 
    <label ><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="psw" id="psw" required  value={password}  onChange={(e)=>setPassword(e.target.value)}/>
   
    <label ><b>Confirm Password</b></label>
    <input type="password" placeholder="Enter Password" name="psw" id="psw" required  value={passwordc}  onChange={(e)=>setPasswordc(e.target.value)}/>
    <hr/>
    <b style={{color:"red"}}>{
  (message!="")?
  message:null
}</b>
<br/>
<br/>

    <p>By creating an account you agree to our <a href="#">Terms & Privacy</a>.</p>
    <a className="abutton"><button type="submit" className="registerbtn">Register</button></a>
  </div>

  <div className="container signin">
    <p>Already have an account?
<Link to={`/login`}> <a href="#">Sign in</a>.</Link></p>
  </div>
</form>
</>
:
(show==="customer")?

<>
          <Link to="/register" style={{marginLeft:"1rem", fontSize:"1.3rem" ,color:"#102030"}} onClick={()=>{setShow("option")}}>Go Back</Link>
<form onSubmit={submitCustomer}>
<div className="containerrrr">
<h1>Customer Register</h1>
<p>Please fill in this form to create an account.</p>
<hr/>


<label><b>Customer name</b></label>
<input type="text" placeholder="Enter customername" name="cname" id="cname" required   value={cname}  onChange={(e)=>setCname(e.target.value)}/>

<label><b>Email</b></label>
<input type="text" placeholder="Enter Email" name="email" id="email" required  value={email}  onChange={(e)=>setEmail(e.target.value)}/>

<label><b>Phone No.</b></label>
<input type="text" placeholder="Enter phoneNo" name="phoneNo" id="phoneNo" required  value={phoneNo}  onChange={(e)=>setPhoneNo(e.target.value)}/>


<label ><b>Password</b></label>
<input type="password" placeholder="Enter Password" name="psw" id="psw" required  value={password}  onChange={(e)=>setPassword(e.target.value)}/>

<label ><b>Confirm Password</b></label>
<input type="password" placeholder="Enter Password" name="psw" id="psw" required  value={passwordc}  onChange={(e)=>setPasswordc(e.target.value)}/>
<hr/>
<b style={{color:"red"}}>{
(message!="")?
message:null
}</b>
<br/>
<br/>

<p>By creating an account you agree to our <a href="#">Terms & Privacy</a>.</p>
<a className="abutton"><button type="submit" className="registerbtn">Register</button></a>
</div>

<div className="container signin">
<p>Already have an account?
<Link to={`/login`}> <a href="#">Sign in</a>.</Link></p>
</div>
</form>
</>
:

<>
          <Link to="/register" style={{marginLeft:"1rem", fontSize:"1.3rem" ,color:"#102030"}} onClick={()=>{setShow("option")}}>Go Back</Link>
<form onSubmit={submitAdmin}>
<div className="containerrrr">
<h1>Admin Register</h1>
<p>Please fill in this form to create an account.</p>
<hr/>


<label><b>Admin name</b></label>
<input type="text" placeholder="Enter adminname" name="aname" id="aname" required   value={aname}  onChange={(e)=>setAname(e.target.value)}/>

<label><b>Email</b></label>
<input type="text" placeholder="Enter Email" name="email" id="email" required  value={email}  onChange={(e)=>setEmail(e.target.value)}/>

<label><b>Phone No.</b></label>
<input type="text" placeholder="Enter phoneNo" name="phoneNo" id="phoneNo" required  value={phoneNo}  onChange={(e)=>setPhoneNo(e.target.value)}/>


<label ><b>Password</b></label>
<input type="password" placeholder="Enter Password" name="psw" id="psw" required  value={password}  onChange={(e)=>setPassword(e.target.value)}/>

<label ><b>Confirm Password</b></label>
<input type="password" placeholder="Enter Password" name="psw" id="psw" required  value={passwordc}  onChange={(e)=>setPasswordc(e.target.value)}/>
<hr/>
<b style={{color:"red"}}>{
(message!="")?
message:null
}</b>
<br/>
<br/>

<p>By creating an account you agree to our <a href="#">Terms & Privacy</a>.</p>
<a className="abutton"><button type="submit" className="registerbtn">Register</button></a>
</div>

<div className="container signin">
<p>Already have an account?
<Link to={`/login`}> <a href="#">Sign in</a>.</Link></p>
</div>
</form>
</>
}
</>
    );
}


export default Register;