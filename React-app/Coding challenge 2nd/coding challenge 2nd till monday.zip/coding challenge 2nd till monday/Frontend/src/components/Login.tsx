import './login.css';
import { useHistory, Redirect} from 'react-router-dom';
import Axios from "axios";
import {Link} from 'react-router-dom';
import { useState,useContext} from 'react';
import * as Bms from "../reducers/bms-reducer";
import {bmsContext} from "../reducers/bms-context";

function Login(){ 
const history = useHistory();

const[show,setShow]=useState("option");
const[token,setToken]=useState("");
const[valid,setValid]=useState("");
  const[message,setMessage]=useState("");
  const[email,setEmail]=useState("");
  const[cemail,setCEmail]=useState("");
  const[aemail,setAEmail]=useState("");
  const[password,setPassword]=useState("");

  let {dispatch}=useContext(bmsContext);
  const token1= localStorage.getItem("authToken")
  if(token1!==null){
    history.push("/");
  }
  
  function submit(e:any){
    e.preventDefault();
    if ( password === "") {
       alert("All the fields are mandatory!");
       return;
     }
   console.log('hyy')
   let data={email,password};
   
   let customer={cemail,password};
   let admin={aemail,password};
   
  console.log(data);

  

   Axios.post("http://localhost:4555/app/user/login",data)
   .then(res=>{ 
     
    const{...data}= res.data;
    if(data.message!==""){

      if(data.message==="login successfull!"){
      setMessage(email + " "+data.message)
      console.log(message)
      }

      if(data.message==="login successfull!"){
      setMessage(email + " "+data.message)
        localStorage.setItem("authToken",data.token);
    localStorage.setItem("screen","user");
       setToken(data.token)
       dispatch({type: Bms.USER,payload:"user"})
       
        console.log(token)
        setValid("success")
    }
  }
    
   })
   .catch(error=>{
       console.log(error)
   });

   
   Axios.post("http://localhost:4555/app/customer/login",customer)
   .then(res=>{ 
     
    const{...data}= res.data;
    if(data.message!==""){
    
      if(data.message==="login successfull!"){
        setMessage(email + " "+data.message)
        console.log(message)
        }
  
        if(data.message==="login successfull!"){
        setMessage(email + " "+data.message)
        localStorage.setItem("authToken",data.token);
        localStorage.setItem("screen","customer");
       setToken(data.token)
       
  dispatch({type: Bms.USER,payload:"customer"})
        console.log(token)
        setValid("success")
    }}
    
   })
   .catch(error=>{
       console.log(error)
   });


   Axios.post("http://localhost:4555/app/admin/login",admin)
   .then(res=>{ 
     
    const{...data}= res.data;
    if(data.message!==""){
    
      if(data.message==="login successfull!"){
        setMessage(email + " "+data.message)
        console.log(message)
        }
  
        if(data.message==="login successfull!"){
        setMessage(email + " "+data.message)
        localStorage.setItem("authToken",data.token);
        localStorage.setItem("screen","admin");
       setToken(data.token)
       dispatch({type: Bms.USER,payload:"admin"})
       
        console.log(token)
        setValid("success")
    }}
    
   })
   .catch(error=>{
       console.log(error)
   });
  }



  if(valid=="success"){
 return <Redirect to="/"/>
}else{
    return(
      <>
 {
(show==="option")?
<div>      
    <button className="buttonlo" type="submit" onClick={()=>{setShow("user")}}>User Login</button>
    <h4 style={{margin:"0 auto",textAlign:"center" }}>OR</h4>
    <button className="buttonlo" type="submit" onClick={()=>{setShow("customer")}}>Customer/Shop Login</button>
    <h4 style={{margin:"0 auto", textAlign:"center"}}>OR</h4>
    <button className="buttonlo" type="submit" onClick={()=>{setShow("admin")}}>Admin Login</button>
    </div>
    :    
    (show==="user")?
<>
          <Link to="/login" style={{marginLeft:"1rem", fontSize:"1.3rem" ,color:"#102030"}} onClick={()=>{setShow("option")}}>Go Back</Link>

    <form className="form23" onSubmit={submit}>
  <div className="imgcontainerrr">
    <img src="https://png.pngtree.com/png-vector/20190225/ourlarge/pngtree-vector-avatar-icon-png-image_702436.jpg" alt="Avatar" className="avatar"/>
  </div>

  <div className="containerrr">
    <label><b> User Email</b></label>
    <input className="inputpsw" type="text" placeholder="Enter Username" name="uname" required   value={email}  onChange={(e)=>setEmail(e.target.value)}/>

    <label><b>Password</b></label>
    <input className="inputpsw" type="password" placeholder="Enter Password" name="psw" required    value={password}  onChange={(e)=>setPassword(e.target.value)}/>
    <b style={{color:"red"}}>{
  (message!="")?
  message:null
}</b>
<br/>
<br/>
    <button className="buttonlo" type="submit">Login</button>
   </div>

</form>
</>
:
(show==="customer")?
<>
<Link to="/login" style={{marginLeft:"1rem", fontSize:"1.3rem" ,color:"#102030"}} onClick={()=>{setShow("option")}}>Go Back</Link>

<form className="form23" onSubmit={submit}>
<div className="imgcontainerrr">
  <img src="https://png.pngtree.com/png-vector/20190225/ourlarge/pngtree-vector-avatar-icon-png-image_702436.jpg" alt="Avatar" className="avatar"/>
</div>

<div className="containerrr">
  <label><b> Customer Email</b></label>
  <input className="inputpsw" type="text" placeholder="Enter Username" name="uname" required   value={cemail}  onChange={(e)=>setCEmail(e.target.value)}/>

  <label><b>Password</b></label>
  <input className="inputpsw" type="password" placeholder="Enter Password" name="psw" required    value={password}  onChange={(e)=>setPassword(e.target.value)}/>
  <b style={{color:"red"}}>{
(message!="")?
message:null
}</b>
<br/>
<br/>
  <button className="buttonlo" type="submit">Login</button>
 </div>

</form>
</>
:
<>
<Link to="/login" style={{marginLeft:"1rem", fontSize:"1.3rem" ,color:"#102030"}} onClick={()=>{setShow("option")}}>Go Back</Link>

<form className="form23" onSubmit={submit}>
<div className="imgcontainerrr">
  <img src="https://png.pngtree.com/png-vector/20190225/ourlarge/pngtree-vector-avatar-icon-png-image_702436.jpg" alt="Avatar" className="avatar"/>
</div>

<div className="containerrr">
  <label><b>Admin Email</b></label>
  <input className="inputpsw" type="text" placeholder="Enter Username" name="uname" required   value={aemail}  onChange={(e)=>setAEmail(e.target.value)}/>

  <label><b>Password</b></label>
  <input className="inputpsw" type="password" placeholder="Enter Password" name="psw" required    value={password}  onChange={(e)=>setPassword(e.target.value)}/>
  <b style={{color:"red"}}>{
(message!="")?
message:null
}</b>
<br/>
<br/>
  <button className="buttonlo" type="submit">Login</button>
 </div>

</form>
</>
}
</>
    );
}
}
export default Login;