
import './shoplistgrid.css';
import { useHistory,Link} from 'react-router-dom';
import {useState,useEffect} from "react";
import Axios from "axios";

 function Shoplistgrid(){
   
 const token= localStorage.getItem("authToken")
  const history = useHistory();
  const[myShops,setShops]= useState([]);
  
  const[productAarry,setProductarray]= useState([]);
  
  const[show,setShow]= useState("shop");

  useEffect(()=>{
  getlist();
  },[]);
 
  
  function getlist(){
    fetch('http://localhost:4555/app/shop',{
      method:"GET",
      headers:{"Content-Type":"application/json"}
    })
    .then(res=>{
      return res.json();
    })
    .then(data=>{
      setShops(data);  
    });
  }
  
  function deleteShop(sname:any) {
    fetch(`http://localhost:4555/app/shop/delete/${sname}`,{
        method:'DELETE'
      }).then((result)=>{
        getlist();
        result.json().then((resp)=>(
          console.log(resp)
        ))
        })
}

function displayProducts(array:any) {
  setShow("details");
  setProductarray(array)
}
  
    if(token==null){
      return <> <h1>Please First Go to Home, Thank You!</h1> </>;;
     }else{
    return(
        
      (show==="shop")?
    <div style={{backgroundColor:"silver"}}>
      <div style={{display:"block", clear:"left" ,color:"black"}}>
      <h2>Shop List :</h2>
      </div>
       
<div className="bgimage2">
      <div className="grid-container">
      {
        myShops.map((post:any)=>{ 
            return(
               
                  <div className="grid-item">
                  <b>Shop name : </b> 
                  {post.sname}
                  <br/><b>Shop Owner : </b> 
                   {post.owner}
                  <br/><b>Shop Location : </b> 
                   {post.location}
                  <br/><b>Category: </b>
                   {post.category}   
                   <br/><b>Offer: </b>
                   {post.offer}%   
                   <br/>
                   <p  onClick ={()=>{displayProducts(post.products)}} style={{color:"blue" , cursor:"pointer", textDecoration:"underline"}}>See Shop Products</p>
                   <button onClick={()=>{deleteShop(post.sname)}} id="searchBut">Delete</button>              
             </div>           
            );
            
      })
     }
    </div>
    </div>
     </div>
     : 
     <div className="bgimage2">
     <h1>Products : </h1> 
     <div className="grid-containerp">
     {
       (productAarry.length===0)?
       <h3>No product Found...</h3>
       :
       productAarry.map((post:any)=>{ 
           return(
                 <div className="grid-itemp">
                 {post}
                </div>           
           );
           
     })
     
    }
   </div>
   <div>
   <br/><button onClick={()=>{setShow("shop")}} id="searchBut" >Go Back to Shop List</button> </div>
   </div>
   
     );
    
  }      
}

export default Shoplistgrid;
