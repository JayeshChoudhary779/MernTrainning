const mongoose = require('mongoose')


const shopschema= new mongoose.Schema({
    
    sname: {
        type: String,
        required: true,
    },
  
    sowner: {
        type: String,
        required: true
    },
       
    location: {
            type: Number,
            required: true
    }   
})

module.exports = mongoose.model('shops',shopschema);