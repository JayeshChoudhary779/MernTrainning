
const admincopy = require('../models/adminmodel');

const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

//register the details
exports.signUp =(req,res)=>{
    var adminname= req.body.email


    admincopy.findOne({email:adminname})
    .then(admin=>{
        if(admin){
            res.json({
                message : "admin already exsist, Please try with other email"
            })
        }else{
    bcrypt.hash(req.body.password, 10, function(err,hashedPass){
        if(err){
            res.json({
               
                message:"error occured in encyrption"
            })
        }
        let admin = new admincopy({
            aname:req.body.aname,
            phoneNo:req.body.phoneNo,
            email: req.body.email,
            password: hashedPass
    })
    admin.save()
    .then(admin=>{
        res.json({
            message:'admin added succesfully, You can sign In now!'
        })
    })
    .catch(error =>{
        res.json({
            message:'error'
        })
    })
})

}}
)}



// login admin
exports.login =(req,res)=>{
    var adminname= req.body.email
    var password= req.body.password

    admincopy.findOne({email:adminname})
    .then(admin=>{
        if(admin)
        {
         bcrypt.compare(password, admin.password, function(err,result) {
             if(err){
                 res.json({
                     error:err
                 })
             }
             if(result){
          
                 let token =jwt.sign({name:admin.name}, "jh",{expiresIn : "30min"})
                 res.json({
                     message: "login successfull!",
                     token : token
                 })
                
                }else{
                    res.json({
                        message: "password doesnot match, Please fill the correct password!"
                    })
                }
    })
}else{
    res.json({
        message : "Invalid email, Please try with correct email"
    })
}
})
}


// login admin with otp
exports.loginWithOtp =(req,res)=>{
    var moNumber= req.body.moNumber

    admincopy.findOne({phoneNo:moNumber})
    .then(result=>{
        if(result){
            res.status(200).json({
                     message: "registered Number"
                 })
        }else{
            res.json({
                message : "Not a registered Number"
                })}
})
.catch(error=>{
    error
})
}




