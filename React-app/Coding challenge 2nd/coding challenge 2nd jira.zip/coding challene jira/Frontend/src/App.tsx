
import Header from './components/Header';
import Mainscreen from './screen/Mainscreen';
import Goodlistgrid from './components/goodlistgrid';
import Login from './components/Login';
import Logout from './components/Logout';
import Register from './components/Register';
import {BrowserRouter as Router, Switch, Route, BrowserRouter,Link} from 'react-router-dom';
import Addgood from './components/Addgood';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';

function App() {

  return (
    <>
    
    <BrowserRouter>
    <Router>
    <Header/>
    <Switch>
     <Route exact path="/" component = {Mainscreen}/>
     <Route path="/Goodsgrid" component ={Goodlistgrid}/>
     <Route path="/Add_Goods" component ={Addgood}/>
     <Route path="/logout" component ={Logout}/>
     <Route path="/login" component ={Login}/>
     <Route path="/register" component ={Register}/>
    </Switch>
    </Router>
    </BrowserRouter>
    
    </>
    
  );
}

export default App;
