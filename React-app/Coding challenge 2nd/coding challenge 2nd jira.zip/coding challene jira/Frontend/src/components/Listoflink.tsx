
import {Link} from 'react-router-dom';

function List(){
    return(
<div className="topnav2">
<ul>
    
<Link to={`/`}><li><a href="#">Home</a></li></Link>
<Link to={`/Goodsgrid`}><li><a href="#">Items/Goods</a></li></Link>
<Link to={`/Add_Goods`}><li><a href="#">Add Goods</a></li></Link>
<Link to={`/register`}><li style={{float:"right"}}><a href="#Register">Register</a></li></Link>
<Link to={`/logout`}><li style={{float:"right"}}><a href="#Logout">LogOut</a></li></Link>
<Link to={`/login`}><li style={{float:"right"}}><a href="#Login">Login</a></li></Link>
</ul>
</div>
    )}

export default List;