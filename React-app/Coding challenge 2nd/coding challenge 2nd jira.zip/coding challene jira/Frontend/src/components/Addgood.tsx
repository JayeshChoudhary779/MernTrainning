
import { useHistory } from 'react-router-dom';
import './Addgoodstyle.css';
import  { useState } from 'react';
import Axios from "axios";

function Addgood(){
    
  
const token= localStorage.getItem("authToken")
const[message,setMessage]=useState("");
const history = useHistory();

    
    const[name,setName]=useState("");
    const[offer,setOffer]=useState("");
    const[price,setPrice]=useState("");
    const[rating,setRating]=useState("");
  
    function submit(e:any){
     e.preventDefault();
     if ( name ==="" || offer==="" || price === ""||rating === "") {
        alert("All the fields are mandatory!");
        return;
      }
    console.log('hyy')
    let data={name,offer,price,rating};

    console.log(data);
     

    Axios.post("http://localhost:4555/app/good/addGood",data)
    .then(res=>{
      const{...data1}= res.data;
     if(data1.message!==""){
       setMessage(data1.message)
       console.log(data1.message)
     }
     if(data1.message==="unique name"){
    history.push("/Goodsgrid");
     }
    })
    .catch(error=>{
        console.log(error)
    });
    
    }
    if(token==null){
      return <> <h1>Please First Go to Home, Thank You!</h1> </>;;
     }else{
return(
  
<div className="bgimage">
    <div className="container">
       
  <h2 style ={{color: "white"}}>Add new Good/Item details...</h2>
                   
         <form onSubmit={submit}>
             <br/>
                     <input type="text" id="name" placeholder="Good/item name.." name="name" value={name} onChange={(e)=>setName(e.target.value)}/>
                     <br/>
                     <input type="text" id="offer" placeholder="offer..." name="offer" value={offer} onChange={(e)=>setOffer(e.target.value)}/>
                     <br/>
                     <input type="text" id="price" placeholder="price..." name="price" value={price} onChange={(e)=>setPrice(e.target.value)}/>
                     <br/>
                     <input type="text" id="rating" placeholder="rating..."name="rating" value={rating} onChange={(e)=>setRating(e.target.value)} />
                     
                     <b style={{color:"white"}}>{
  (message!="")?
  message:null
}</b>
<br/>
<br/>
                     <input type ="submit" value='ADD FILM' id="addbutton" />

                   </form>
                 </div>
                 </div>
               
       );
    
}}
export default Addgood;

