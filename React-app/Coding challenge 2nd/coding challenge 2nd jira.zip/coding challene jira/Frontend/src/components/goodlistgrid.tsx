
import './goodlistgrid.css';
import { useHistory,Link} from 'react-router-dom';
import {useState,useEffect} from "react";
import Axios from "axios";

 function Goodlistgrid(){
   
 const token= localStorage.getItem("authToken")
  const history = useHistory();
  const[myGoods,setGoods]= useState([]);

  useEffect(()=>{
  getlist();
  },[]);
 
  
  function getlist(){
    fetch('http://localhost:4555/app/good/getGood',{
      method:"GET",
      headers:{"Content-Type":"application/json"}
    })
    .then(res=>{
      return res.json();
    })
    .then(data=>{
      setGoods(data);  
    });
  }
  
  
    if(token==null){
      return <> <h1>Please First Go to Home, Thank You!</h1> </>;;
     }else{
    return(
       
      <div className="grid-container">
      {
        myGoods.map((post:any)=>{ 
            return(
               
                  <div className="grid-item">
                  <b>Good name : </b> 
                  {post.name}
                  <br/><b>Good offer : </b> 
                   {post.offer}
                  <br/><b>Good price : </b> 
                   {post.price}
                  <br/><b>Rating : </b>
                   {post.rating}            
                  </div>    
            );
            
      })
     }
    </div>
    );
    
  }      
}

export default Goodlistgrid;
