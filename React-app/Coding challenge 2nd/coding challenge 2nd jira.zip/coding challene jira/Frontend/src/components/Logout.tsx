
import {useHistory} from 'react-router-dom';
function Logout(){

    
    const history = useHistory();
    if(!(window.confirm("Are you sure?"))){
     history.push("/")
    }

    localStorage.removeItem("authToken")
   

    return(
        <>
        <h1>Thank you !</h1>
        <h1>You have been logged out, Now you will be in View Mode!</h1>
        </>
    );
    
}

export default Logout;