
  
import React from 'react';

const MovieList = (props) => {

    const {movies}=props;
    console.log("prop movie:", movies)
    console.log("prop movie list:", movies.Search)


	return (
		<>
       
			{movies.Search.map((movie, index) => (
				<div className='image-container d-flex justify-content-start m-3'>
					<img src={movies.Poster} alt='movie'></img>
				</div>
			 ))} 
            
            
		</>
	);
};

export default MovieList;