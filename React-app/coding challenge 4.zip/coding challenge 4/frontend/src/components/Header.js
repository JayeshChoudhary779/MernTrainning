
import { Nav ,Navbar,Form,FormControl,Button} from 'react-bootstrap';
import { NavLink } from 'react-router-dom'
import { signout } from '../actions/userActions';
import { useDispatch, useSelector} from 'react-redux';
import 'bootstrap/dist/css/bootstrap.min.css';

export default function Header() {
    
  const userSignin = useSelector((state) => state.userSignin);
  const { userInfo,loading, error } = userSignin;

  
  const dispatch = useDispatch();
  const signoutHandler = () => {
    dispatch(signout());
  };

    return (
<Navbar bg="dark" variant="dark">
<Navbar.Brand  as={NavLink} to='/' exact>Movies</Navbar.Brand>
 <Form inline style={{marginLeft:"21rem"}}>
      <FormControl type="text" placeholder="Search" style={{width:"25rem"}} className="mr-sm-2" />
      <Button variant="outline-light">Search</Button>
</Form>
<Nav className="ml-auto ">
<Nav.Link as={NavLink} to='/' exact>Home</Nav.Link>
{(userInfo)?
<Nav.Link as={NavLink} to='#signout'  onClick={signoutHandler}>Signout</Nav.Link>
:
<>
<Nav.Link as={NavLink} to='/signin' >Signin</Nav.Link>
<Nav.Link as={NavLink} to='/register'>Register</Nav.Link>
</>
}
</Nav>
</Navbar>
    )
}