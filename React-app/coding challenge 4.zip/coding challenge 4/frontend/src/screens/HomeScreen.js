import { useHistory } from "react-router"
import Axios from 'axios';
import React, { useEffect ,useState} from 'react';
import LoadingBox from '../components/LoadingBox';
import MovieList from '../components/MovieList';
import MessageBox from '../components/MessageBox';
import 'bootstrap/dist/css/bootstrap.min.css';
import { useDispatch, useSelector } from 'react-redux';

export default function HomeScreen() {

  const[movies,setMovies]=useState([])

  const getMovieRequest = async (searchValue) => {
		const url = `http://www.omdbapi.com/?s=marvel&apikey=283ed57f`;

		const response = await fetch(url);
		const responseJson = await response.json();

		// if (responseJson.Search) {
			setMovies(responseJson);
		// }
	};

  useEffect(() => {
    getMovieRequest();
  });

  console.log("movies",movies)

  return (
    		<div className='container-fluid'>
        <div className='row'>
				<MovieList
					movies={movies}
				/>
			</div>
		</div>
  );
}