import React from 'react';
import 'font-awesome/css/font-awesome.min.css';
import { useDispatch, useSelector } from 'react-redux';
import { Route,BrowserRouter,Switch} from 'react-router-dom';
import { BrowserRouter as Router } from 'react-router-dom';
import { signout } from './actions/userActions';
import HomeScreen from './screens/HomeScreen';
import RegisterScreen from './screens/RegisterScreen';
import SigninScreen from './screens/SigninScreen';
import Header from './components/Header';


function App() {

  const userSignin = useSelector((state) => state.userSignin);
  const { userInfo } = userSignin;

  const dispatch = useDispatch();
  const signoutHandler = () => {
    dispatch(signout());
  };

  return (
    <BrowserRouter>
    <Router>
     <Header/>
    <Switch>
          <Route path="/signin" component={SigninScreen}></Route>
          <Route path="/register" component={RegisterScreen}></Route>
          <Route path="/" component={HomeScreen} exact></Route>
    </Switch>
    </Router>
    <div className="footer bg-dark ">
    <p>Created By Jayeshchoudhary | <i className="fa fa-copyright"></i> 2021 All rights reserved.</p>
  </div>
    </BrowserRouter>
  );
}

export default App;